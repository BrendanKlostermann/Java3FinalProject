create
    definer = Brendan@`%` procedure insert_user(IN first_name varchar(255), IN last_name varchar(255),
                                                IN email varchar(255), IN password varchar(255), IN role varchar(255))
BEGIN
    INSERT INTO users (first_name, last_name, email, password, role) VALUES (first_name, last_name, email, password, role);
END;

