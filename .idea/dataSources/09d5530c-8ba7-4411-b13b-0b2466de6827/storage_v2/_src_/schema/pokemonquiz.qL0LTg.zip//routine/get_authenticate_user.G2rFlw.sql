create
    definer = Brendan@`%` procedure get_authenticate_user(IN inPassword varchar(255))
BEGIN
    Select row_count() from users Where password = inPassword;

END;

