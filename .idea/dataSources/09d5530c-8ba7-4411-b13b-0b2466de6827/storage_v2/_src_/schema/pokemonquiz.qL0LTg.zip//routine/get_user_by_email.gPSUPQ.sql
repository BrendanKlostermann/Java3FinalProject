create
    definer = Brendan@`%` procedure get_user_by_email(IN email varchar(255))
BEGIN
    SELECT * FROM users WHERE email = email;
END;

